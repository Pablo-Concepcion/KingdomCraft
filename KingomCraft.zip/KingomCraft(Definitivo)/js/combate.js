nivelPersonaje = localStorage.getItem("nivelPersonaje");
defensaProta = parseFloat(localStorage.getItem("porcentajeDefensa"));
vidaPersonaje = parseInt(localStorage.getItem("vidaPersonaje"));
defensaProtaOriginal = localStorage.getItem("porcentajeDefensaOriginal");
atqProtaOriginal = localStorage.getItem("porcentajeAtaqueOriginal");
objetos = localStorage.getItem("objetos");
objeto = objetos.split(",");
objetos = "";
habilidades = localStorage.getItem("habilidades");
skill = habilidades.split(",");
habilidad = "";
vida = localStorage.getItem("vida");
vidaO = localStorage.getItem("vidaPersonajeOriginal");
expFaltante = localStorage.getItem("experienciaFaltante");
vecesDefendidas = 0;
localStorage.setItem("expOriginal", 60);
expOriginal = localStorage.getItem("expOriginal");
selectObjetos = "";
atqBicho = "";
defensaBicho = "";
estadisticas = {
    exp: [],
    vida: [],
    atq: [],
    def: []
};
mensajes = "";
enemigos = localStorage.getItem("enemigos");
enemigo = enemigos.split(",");



//vidaPersonaje = 20;

vidaLimite = parseInt(parseInt(vidaPersonaje) * 0.4);
estadoDelJugador = "";
bicho = ""; //usado para generar las animaciones de las habilidades
sexo = localStorage.getItem("sexo");
if (sexo == "Mujer") {
    player = "playera";
} else {
    player = "player";
}

function mostrar() {

    statusBicho = [];
    num = sub();
    bicho = document.getElementById("bicho");
    bicho.style.background = "url(../img/" + enemigo[num] + ") no-repeat";
    bicho.style.backgroundSize = "contain";
    nombreDelEnemigo = enemigo[num].split(".")[0];
    buscar = "datosDel" + nombreDelEnemigo;
    datosDelBicho = localStorage.getItem(buscar);
    caracDelBicho = datosDelBicho.split(","); //características del bicho
    for (i = 0; i < caracDelBicho.length; i++) {
        statusBicho[i] = caracDelBicho[i];

    }
    for (j = 0; j < statusBicho.length; j++) {
        masDatos(j, statusBicho[j].split(" ")[1]);
    }

    document.getElementById("estadoBicho").innerHTML = nombreDelEnemigo + "<br>Vida= " + estadisticas.vida[1];
    document.getElementById("estadoJugador").innerHTML = "Nivel: " + nivelPersonaje + "<br>Vida= " + vidaPersonaje;
    divPlayer = document.getElementById("player");
    divPlayer.id = player;
    pocasCosas();
    atqBicho = estadisticas.atq[2];
    vidaBicho = estadisticas.vida[1];
    defensaBicho = estadisticas.def[3];
    habilitar();
}

function masDatos(i, estado) {
    switch (i) {
        case 0:
            estadisticas.exp[i] = estado;
            break;
        case 1:
            estadisticas.vida[i] = estado;
            break;
        case 2:
            estadisticas.atq[i] = estado;
            break;
        case 3:
            estadisticas.def[i] = estado;
            break;
        default:
            break;
    }
}

function atacar() {
    poderDeAtaque = localStorage.getItem("porcentajeAtaque");
    danoMio = Math.floor(parseFloat(poderDeAtaque) * parseFloat(vida));
    danoAbsorbido = Math.floor(parseFloat(defensaBicho) * parseFloat(vidaBicho));
   // danoAbsorbido = danoAbsorbido / 2;
   
    
    if(nivelPersonaje<20 && num == 4) // el combate final tiene que costar un poco ;)
    {
        danoMio = 20;
     
    }

    danoTotal = danoMio - danoAbsorbido;

    if (danoTotal === 0 || danoTotal <0) {
        danoTotal = 50;
    }
    vidaBicho = vidaBicho - Math.abs(danoTotal);
    if (vidaBicho <= 0) {
        toastear('exito', '¡Has derrotado al enemigo!', 'Enemigo derrotado');
        document.getElementById("bicho").style.backgroundColor = "red";
        subirNivel();
        terminarPelea();
        document.getElementById("estadoBicho").innerHTML = nombreDelEnemigo + "<br>Vida= " + 0;
    } else {
        document.getElementById("estadoBicho").innerHTML = nombreDelEnemigo + "<br>Vida= " + parseInt(vidaBicho);
        ataqueEnemigo();
    }
}

function defender() {
    if (vecesDefendidas < 3) {
        defensaProta = parseFloat(defensaProta + 0.2);
        toastear('info', '¡Tu defensa ha aumentado un poco!', 'Defensa reforzada');
        ataqueEnemigo();
        vecesDefendidas++;
    } else {
        toastear('warning', '¡Tu defensa no puede subir más!', 'Mucha defensa');
    }
}

function ataqueEnemigo() {

    if (atqBicho == defensaProta) {
        PorcAtqBicho = atqBicho - (defensaProta + 0.5);
    } else if (atqBicho > defensaProta) {
        PorcAtqBicho = atqBicho - defensaProta;
    } else {
        PorcAtqBicho = defensaProta - atqBicho;
    }
    dano = Math.floor(parseFloat(PorcAtqBicho) * parseFloat(vidaBicho));
    if (dano < 0) {
        dano = 20;
    }
    if(num >=2 && num <4 && nivelPersonaje <20)
        {
           dano = parseInt(estadisticas.vida[1]);
        }
    if(num == 4 && nivelPersonaje <20)
    {
        dano = vidaBicho -20;
    }
    vidaPersonaje = vidaPersonaje - dano;
    if (vidaPersonaje <= 0) {
        estadoDelJugador = document.getElementById("estadoJugador");
        toastear('danger', '¡Has Muerto! Regresa más fuerte', 'Muerto');
        estadoDelJugador.className = "";
        document.getElementById("jugador").className = "";
        document.getElementById("combate").style.backgroundColor = "red";
        estadoDelJugador.innerHTML = "Nivel: " + nivelPersonaje + "<br>Vida= " + 0;
        setTimeout(function(){window.location.assign("casaJefe.html");}, 3000);
        

    } else {
        estadoDelJugador = document.getElementById("estadoJugador");
        comprobarVida(estadoDelJugador);

        estadoDelJugador.innerHTML = "Nivel: " + nivelPersonaje + "<br>Vida= " + vidaPersonaje;

    }
}

function comprobarVida() {

    if (vidaPersonaje <= vidaLimite) {
        estadoDelJugador.className = " muriendo";
        document.getElementById("jugador").className = "muriendo";
        toastear('danger', '¡Estás apunto de morir!', '¡CUIDADO!');

    } else {
        estadoDelJugador.className = "";
        document.getElementById("jugador").className = "";
    }
}

function pocasCosas() {
    selectObjetos = document.getElementById("objeto");
    for (i = 0; i < objeto.length - 1; i++) {
        if (objeto[i] !== null && objeto[i] != undefined && objeto[i] != 'undefined') {
            opcion = document.createElement("option");
            texto = document.createTextNode(objeto[i]);
            opcion.setAttribute("value", objeto[i]);
            opcion.setAttribute("class", objeto[i]);
            opcion.setAttribute("name", objeto[i]);
            opcion.appendChild(texto);
            selectObjetos.appendChild(opcion);
        }

    }
}

function cosas() {
    objetoSeleccionado = selectObjetos.value;
    switch (objetoSeleccionado) {
        case "Poción":
            if (vidaPersonaje < vida) {
                toastear('exito', 'Has usado una poción', 'Poción');
                if(nivelPersonaje <20 && num == 4)
                {
                    toastear("warning", "El enemigo se ha recuperado también!", "Sanación malvada");
                    vidaBicho = estadisticas.vida[1]-40;
                    document.getElementById("estadoBicho").innerHTML = nombreDelEnemigo + "<br>Vida= " + vidaBicho;

                }
                vidaPersonaje += 50;
                if (vidaPersonaje > vida) {
                    vidaPersonaje = vida;
                }
                document.getElementById("estadoJugador").innerHTML = "Nivel: " + nivelPersonaje + "<br>Vida= " + vidaPersonaje;
                buscarObjeto("Poción");
                comprobarVida();
                ataqueEnemigo();
            } else {
                
                toastr.clear();
                toastr.options.positionClass = "toast-top-center";
                toastr.info('No te haría ningún efecto', '<i>Poción</i>');
            }
            break;
        case "MaxPoción":
            if (vidaPersonaje < vida) {
                toastear('exito', 'Has usado una Maxpoción', 'Maxpoción');
                if(nivelPersonaje <20 && num == 4)
                {
                    toastear("warning", "El enemigo se ha recuperado también!", "Sanación demoníaca");
                    vidaBicho = estadisticas.vida[1];
                    document.getElementById("estadoBicho").innerHTML = nombreDelEnemigo + "<br>Vida= " + vidaBicho;

                }
                

                vidaPersonaje = vida;

                document.getElementById("estadoJugador").innerHTML = "Nivel: " + nivelPersonaje + "<br>Vida= " + vidaPersonaje;
                buscarObjeto("MaxPoción");
                comprobarVida();
            } else {
                toastear('info', 'No te haría ningún efecto', 'Maxpoción');
            }
            break;
    }
    localStorage.setItem("vidaPersonaje", vidaPersonaje);
}

function buscarObjeto(obje) {
    agregar = "";
    for (i = 0; i < objeto.length - 1; i++) {
        if (objeto[i] == obje) {
            objetoUsado = document.getElementsByClassName(obje)[0];
            padreObjetoUsado = objetoUsado.parentNode;
            padreObjetoUsado.removeChild(objetoUsado);
            objeto[i] = "usado";
            break;
        }

    }
    for (j = 0; j < objeto.length; j++) {

        if (objeto[j] != "usado" && objeto[j] !== "" && objeto[j] != "undefined" && objeto[j] !== undefined) {
            agregar = agregar + objeto[j] + ",";

        }
    }

    localStorage.setItem("objetos", agregar);
}

function subirNivel() {
    deshabilitarBotones();
    expFaltante = parseInt(expFaltante) - parseInt(estadisticas.exp[0]);
    if (expFaltante <= 0) {
        estadoDelJugador.className = "";
        document.getElementById("jugador").className = "";
        nivelPersonaje++;
        expFaltante = parseInt(expOriginal) + (parseInt(nivelPersonaje) * 10);
        toastear('exito', '¡Has Subido de nivel!', 'Level up!');
        vidaPersonaje = parseInt(vidaO) + parseInt(nivelPersonaje) * 10;
        vida = vidaPersonaje;
        atq = parseFloat(atqProtaOriginal) + 0.2;
        defensa = parseFloat(defensaProtaOriginal) + 0.1;
        localStorage.setItem("porcentajeAtaque", atq);
        localStorage.setItem("porcentajeDefensa", defensa);
        localStorage.setItem("nivelPersonaje", nivelPersonaje);
        localStorage.setItem("vida", vida);
        document.getElementById("estadoJugador").innerHTML = "Nivel: " + nivelPersonaje + "<br>Vida= " + vidaPersonaje;
        if (nivelPersonaje == 5) {
            toastear('info', 'Has aprendido Espada Fugaz', 'Espada Fugaz');
        }
        if (nivelPersonaje == 10) {
            toastear('info', 'Has aprendido Espada Lateral', 'Espada Lateral');
        }
        if (nivelPersonaje == 15) {
            toastear('info', 'Has aprendido Espada Sabia', 'Espada Sabia');
        }
        if (nivelPersonaje == 20) {
            toastear('info', 'Has aprendido Espada Mortal', 'Espada Mortal');
        }

    }

    localStorage.setItem("experienciaFaltante", expFaltante);
    localStorage.setItem("vidaPersonaje", vidaPersonaje);

}

function habilitar() {
    habilidad = document.getElementById("skill");
    for (i = 0; i < skill.length; i++) {
        opcion = document.createElement("option");
        texto = document.createTextNode(skill[i]);
        opcion.setAttribute("value", skill[i]);
        opcion.setAttribute("class", skill[i]);
        opcion.setAttribute("name", skill[i]);
        opcion.appendChild(texto);
        habilidad.appendChild(opcion);
    }
}

function usarHabilidad() {
    skillselec = habilidad.value;
    switch (skillselec) {
        case "Espada fugaz":
            if (nivelPersonaje >= 5) {

                bicho.setAttribute("class", "girada");
                toastear('exito', 'Has usado Espada Fugaz', 'Espada Fugaz');
                atqskill(50);

            } else {
                toastear('info', 'Necesitas llegar al nivel 5', 'Todavía no puedes');
            }
            break;
        case "Espada lateral":
            if (nivelPersonaje >= 10) {

                bicho.setAttribute("class", "lateral");
                toastear('exito', 'Has usado Espada Lateral', 'Espada Lateral');
                atqskill(100);
            } else {
                toastear('info', 'Necesitas llegar al nivel 10', 'Todavía no puedes');
            }
            break;
        case "Espada sabia":
            if (nivelPersonaje >= 15) {

                bicho.setAttribute("class", "sabia");
                toastear('exito', 'Has usado Espada Sabia', 'Espada Sabia');
                atqskill(150);
            } else {
                toastear('info', 'Necesitas llegar al nivel 15', 'Todavía no puedes');
            }
            break;
        case "Espada mortal":
            if (nivelPersonaje >= 20) {
                bicho.setAttribute("class", "mortal");
                toastear('exito', 'Has usado Espada Mortal', 'Espada Mortal');
                atqskill(200);
            } else {
                toastear('info', 'Necesitas llegar al nivel 20', 'Todavía no puedes');
            }
            break;
    }
}

function atqskill(fuerza) {
    vidaBicho = vidaBicho - fuerza;
    if (vidaBicho <= 0) {
        toastear('exito', '¡Has derrotado al enemigo!', 'Enemigo derrotado');
        document.getElementById("bicho").style.backgroundColor = "red";
        subirNivel();
        terminarPelea();
        document.getElementById("estadoBicho").innerHTML = nombreDelEnemigo + "<br>Vida= " + 0;
    } else {
        document.getElementById("estadoBicho").innerHTML = nombreDelEnemigo + "<br>Vida= " + vidaBicho;
        
    }
}






function deshabilitarBotones() {
    butons = document.getElementsByName("boton");
    for (i = 0; i < butons.length; i++) {

        butons[i].disabled = true;
    }

}

function toastear(tipo, texto, title) {
    toastr.clear();
    toastr.options = {'positionClass': "toast-top-center"};
    switch (tipo) {
        case "exito":
            toastr.success(texto, '<i>' + title + '</i>');
            break;
        case "info":
            toastr.info(texto, '<i>' + title + '</i>');
            break;
        case "warning":
            toastr.warning(texto, '<i>' + title + '</i>');
            break;
        case "danger":
            toastr.error(texto, '<i>' + title + '</i>');
            break;
    }

}
function terminarPelea()
{
    if(num == 4)
    {
        localStorage.setItem("Fin", "acabado");
        setTimeout(function () {
            nuevaVentana = window.open("casaJefe.html");
            window.close();
        }, 2000);

    }
    else
    {
        setTimeout(function () {window.close();}, 2000);
    }
        
}
        