fin = localStorage.getItem("Fin");



function crear() {
    esconderCharlas();
    $("#chimenea").hide();
    $("#gracias").hide();
    $("#destruir").hide();
    numeroFilas = 10;
    div = document.getElementsByClassName("tablero")[0];
    table = document.createElement("table");
    for (i = 0; i < numeroFilas - 1; i++) {
        tr = document.createElement("tr");
        for (j = 0; j < numeroFilas; j++) {
            td = document.createElement("td");
            td.setAttribute("id", "" + i + "," + j + "");
            tr.appendChild(td);
        }
        table.appendChild(tr);
    }
    div.appendChild(table);
    crearObjetos();
    for (i = 0; i < cosa.length - 1; i++) {
        agregarAlInventario2(cosa[i]);
    }
    document.getElementById("nombre").innerHTML = localStorage.getItem("Jugador");
    document.getElementById("nivel").innerHTML = "Nivel: " + nivelPersonaje;
    document.getElementById("pv").innerHTML = "PV: " + vidaPersonaje;
    document.getElementById("exp").innerHTML = "Next lvl: " + experienciaFaltante;
}

function crearObjetos() //crea los objetos y personajes del mapa
{
    celdaDondeEmpiezaElJugador = document.getElementById("8,1");
    celdaDondeEmpiezaElJugador.className = "j " + generoJugador + "_arriba";
    document.getElementById("0,0").className = "obstaculo mesa ";
    document.getElementById("0,3").className = "obstaculo curacion";
    document.getElementById("0,1").className = "obstaculo silla";
    document.getElementById("3,4").className = "obstaculo constructor_abajo";
    document.getElementById("0,8").className = "obstaculo cofre maxPocion";
    document.getElementById("0,9").className = "obstaculo chimenea";
}

function comprobarPosicion(objeto, direccionJugador) {
    orientacionPresonaje = "_" + direccionJugador.split("_")[1];
    constructor = objeto.className.search("constructor");
    eter = objeto.className.search("maxPocion");
    chimenea = objeto.className.search("chimenea");
    curacion = objeto.className.search("curacion");


    salida = objeto.className.search("salida");

    if (constructor > 0) {

        if (fin == "acabado") {
            poderMoverse = false;
            $("#gracias").dialog({
                buttons: {
                    Vale: function () {
                        $(this).dialog("close");
                        poderMoverse = true;
                    }
                },
                close: function () {
                    poderMoverse = true;
                }
            });
        } else {
            var num = 1;
            var num1 = 1;
            hablar(num1, num);
            

        }
        objeto.className = "obstaculo constructor" + orientacionPresonaje;
    }
    if (eter > 0) {
        toastear("warning", "Has encontrado una Maxpoción. <br>Te curará por completo", "MaxPoción");
        objeto.className = "obstaculo cofre abierto";
        agregarAlInventario("MaxPoción");
    }
    if (chimenea > 0) {
        añadir();
        poderMoverse = false;
        $("#chimenea").dialog({
            buttons: {
                Sí: function () {
                    num = 0;
                    window.location.assign("subterraneo.html");
                    poderMoverse = true;
                },
                No: function () {
                    num = 0;
                    $(this).dialog("close");
                    poderMoverse = true;
                },
            },
            close: function () {
                poderMoverse = true;
            }
        });
     

    }
    if (curacion > 0) {
        curar();
        toastear("exito", "Te has curado con las  <br> propiedades mágicas del traje", "Sanación completada");
    }
}

function añadir() {
    agregar = "";
    for (i = 0; i < cosa.length; i++) {
        agregar += cosa[i] + ",";
    }
    localStorage.setItem("objetos", agregar);
}

function moverPersonaje(direccion) {
    if (poderMoverse === true) {
        dir = direccion;
        if (celdaObjetivo !== null) {
            esObstaculo = celdaObjetivo.className.search("obstaculo");
            if (celdaObjetivo !== null && esObstaculo < 0) {
                jugador.className = "";
                celdaObjetivo.className = "j " + generoJugador + "_" + direccion;

            } else {
                jugador.className = "j " + generoJugador + "_" + direccion;
            }
        }
    }
}
