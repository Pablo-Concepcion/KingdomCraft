pasos = 0;
poderMoverse = true;
sexo = localStorage.getItem("sexo");
if (sexo == "Mujer") {
    generoJugador = "jugadora";
} else {
    generoJugador = "jugador";
}

function crear() {
    $("#destruir").hide();
    $("#discurso").hide();
    esconderCharlas();
    numeroFilas = 10;
    div = document.getElementsByClassName("tablero")[0];
    table = document.createElement("table");
    for (i = 0; i < numeroFilas - 1; i++) {
        tr = document.createElement("tr");
        for (j = 0; j < numeroFilas * 2; j++) {
            td = document.createElement("td");
            td.setAttribute("id", "" + i + "," + j + "");
            tr.appendChild(td);
        }
        table.appendChild(tr);
    }
    div.appendChild(table);
    toastear("warning", "¡Ya no puedes volver atrás!", "Aviso");
    crearObjetos();
    for (i = 0; i < cosa.length - 1; i++) {
        agregarAlInventario2(cosa[i]);
    }
    document.getElementById("nombre").innerHTML = localStorage.getItem("Jugador");
    document.getElementById("nivel").innerHTML = "Nivel: " + nivelPersonaje;
    document.getElementById("pv").innerHTML = "PV: " + vidaPersonaje;
    document.getElementById("exp").innerHTML = "Next lvl: " + experienciaFaltante;
    setInterval(colocarEstado, 3000);//actualizar constantemente el estado
}

function crearObjetos() //crea los objetos y personajes del mapa
{
    celdaDondeEmpiezaElJugador = document.getElementById("8,1");
    celdaDondeEmpiezaElJugador.className = "j " + generoJugador + "_arriba";

    document.getElementById("0,14").className = "obstaculo  jefe";
    document.getElementById("5,14").className = "obstaculo  columna";
    document.getElementById("5,15").className = "obstaculo  columna";
    document.getElementById("6,14").className = "obstaculo  cofre maxpocion";
    document.getElementById("0,0").className = "obstaculo  cofre maxpocion";
    document.getElementById("2,0").className = "obstaculo  cofre maxpocion";
    for (i = 0; i < 7; i++) {
        for (j = 13; j < 14; j++) {
            document.getElementById(i + "," + j).className = "obstaculo columna";
        }
    }
    for (i = 0; i < 4; i++) {
        for (j = 15; j < 16; j++) {
            document.getElementById(i + "," + j).className = "obstaculo columna";
        }
    }
    for (i = 7; i < 8; i++) {
        for (j = 5; j < 19; j++) {
            document.getElementById(i + "," + j).className = "obstaculo columna";
        }
    }
    for (i = 1; i < 2; i++) {
        for (j = 0; j < 10; j++) {
            document.getElementById(i + "," + j).className = "obstaculo columna";
        }
    }
    for (i = 3; i < 4; i++) {
        for (j = 0; j < 10; j++) {
            document.getElementById(i + "," + j).className = "obstaculo columna";
        }
    }
}

function moverPersonaje(direccion, celdaObjetivo) {
    if (poderMoverse === true) {

        dir = direccion;
        if (celdaObjetivo !== null) {
            esObstaculo = celdaObjetivo.className.search("obstaculo");
            if (celdaObjetivo !== null && esObstaculo < 0) {
                jugador.className = "";
                if (pasos == 5) //cada 5 pasos se abre un combate 
                {
                    window.open("../pag/combateSub.html");
                    pasos = 0;

                }
                pasos++;

                celdaObjetivo.className = "j " + generoJugador + "_" + direccion;

            } else {
                jugador.className = "j " + generoJugador + "_" + direccion;
            }
        }
    }

}

function colocarEstado()
{
    document.getElementById("nombre").innerHTML = localStorage.getItem("Jugador");
    document.getElementById("nivel").innerHTML = "Nivel: " + nivelPersonaje;
    document.getElementById("pv").innerHTML = "PV: " + localStorage.getItem("vidaPersonaje");
    document.getElementById("exp").innerHTML = "Next lvl: " + localStorage.getItem("experienciaFaltante");
    inventario = document.getElementById("itemsObjetos");
    hijosInventario = inventario.childNodes;
    for (i=hijosInventario.length-1; i>= 0; i--)
    {
        inventario.removeChild(hijosInventario[i]);
    }
    
    objetos = localStorage.getItem("objetos");
    cosa = objetos.split(",");
    for (i = 0; i < cosa.length - 1; i++) {
        agregarAlInventario2(cosa[i]);
    }
}
function comprobarPosicion(objeto) {
    maxpocion = objeto.className.search("maxpocion");
    pocion = objeto.className.search("pocion");
    jefe = objeto.className.search("jefe");
    if (pocion > 0) {
        toastear("info",'Has encontrado una poción', '<i>Poción</i>');
        objeto.className = "obstaculo cofre abierto";
        agregarAlInventario("Poción");
    }
    if (maxpocion > 0) {
        toastear("info",'Has encontrado una MaxPocion', '<i>MaxPoción</i>');
        objeto.className = "obstaculo cofre abierto";
        agregarAlInventario("MaxPoción");
    }
    if (jefe > -1) {

        anadir();
        poderMoverse = false;
        $("#discurso").dialog({
            buttons: {
                "Te vas a enterar": function () {
                    num = 0;
                    $(this).dialog("close");
                },
            },
            close: function () {
                poderMoverse = true;
                window.location.assign("../pag/combateFinal.html");
            }
        });
        objeto.className = "obstaculo jefazo";//segun la clase se muestra el sprite
    }

}

