//Subterraneo
poderMoverse = true;
sexo = localStorage.getItem("sexo");
if (sexo == "Mujer") {
    generoJugador = "jugadora";
} else {
    generoJugador = "jugador";
}
pasos = 0;

function crear() {
    $("#destruir").hide();
    $("#entrada").hide();
    $("#salida").hide();

    esconderCharlas();
    numeroFilas = 10;
    div = document.getElementsByClassName("tablero")[0];
    table = document.createElement("table");
    for (i = 0; i < numeroFilas - 1; i++) {
        tr = document.createElement("tr");
        for (j = 0; j < numeroFilas * 3; j++) {
            td = document.createElement("td");
            td.setAttribute("id", "" + i + "," + j + "");
            tr.appendChild(td);
        }
        table.appendChild(tr);
    }
    div.appendChild(table);
    crearObjetos();
    for (i = 0; i < cosa.length - 1; i++) {
        agregarAlInventario2(cosa[i]);
    }
    document.getElementById("nombre").innerHTML = localStorage.getItem("Jugador");
    document.getElementById("nivel").innerHTML = "Nivel: " + nivelPersonaje;
    document.getElementById("pv").innerHTML = "PV: " + vidaPersonaje;
    document.getElementById("exp").innerHTML = "Next lvl: " + experienciaFaltante;

setInterval(colocarEstado, 3000);//actualizar constantemente el estado




}

function crearObjetos() //crea los objetos y personajes del mapa
{
    celdaDondeEmpiezaElJugador = document.getElementById("8,1");
    document.getElementById("8,0").className = "obstaculo salida";
    celdaDondeEmpiezaElJugador.className = "j " + generoJugador + "_arriba";
    for (i = 1; i < 2; i++) {
        for (j = 0; j < 10; j++) {
            document.getElementById(i + "," + j).className = "obstaculo valla";
        }
    }
    for (i = 7; i < 8; i++) {
        for (j = 15; j < 29; j++) {
            document.getElementById(i + "," + j).className = "obstaculo valla";
        }
    }
    for (i = 3; i < 4; i++) {
        for (j = 15; j <= 29; j++) {
            document.getElementById(i + "," + j).className = "obstaculo valla";
        }
    }
    for (i = 5; i < 6; i++) {
        for (j = 15; j < 29; j++) {
            document.getElementById(i + "," + j).className = "obstaculo valla";
        }
    }
    for (i = 3; i <= 8; i++) {
        for (j = 9; j < 10; j++) {
            document.getElementById(i + "," + j).className = "obstaculo valla";
        }
    }
    for (i = 3; i < 4; i++) {
        for (j = 0; j < 8; j++) {
            document.getElementById(i + "," + j).className = "obstaculo valla";
        }
    }
    document.getElementById("0,0").className = "obstaculo cofre pocion ";
    document.getElementById("2,0").className = "obstaculo cofre pocion ";
    document.getElementById("8,10").className = "obstaculo cofre pocion ";

    document.getElementById("6,28").className = "obstaculo valla";
    document.getElementById("6,27").className = "obstaculo cofre pocion";

    document.getElementById("8,15").className = "obstaculo  girada";
    document.getElementById("8,16").className = "obstaculo  cofre maxpocion";
    document.getElementById("0,29").className = "obstaculo  entrada";



}

function comprobarPosicion(objeto) {
    pocion = objeto.className.search("pocion");
    maxpocion = objeto.className.search("maxpocion");
    entrada = objeto.className.search("entrada");
    salida = objeto.className.search("salida");
    if (pocion > 0) {
        toastear("info",'Has encontrado una poción', '<i>Poción</i>');
        objeto.className = "obstaculo cofre abierto";
        agregarAlInventario("Poción");
    }
    if (maxpocion > 0) {
        toastear("info",'Has encontrado una poción', '<i>MaxPoción</i>');
        objeto.className = "obstaculo cofre abierto";
        agregarAlInventario("MaxPoción");
    }



    if (entrada > -1) {
        anadir();
        $("#salida").dialog({
            buttons: {
                Entro: function () {
                    anadir(); //se añaden los objetos al localStorage cuando se pasa de mapa
                    window.location.assign("zonafinal.html");
                }
            }
        });



    }
    if (salida > 0) {
        
        $("#entrada").dialog({
            buttons: {
                Entro: function () {
                    anadir(); //se añaden los objetos al localStorage cuando se pasa de mapa
                    window.location.assign("casajefe.html");
                }
            }
        });


    }

}

function anadir() {
    agregar = "";
    for (i = 0; i < cosa.length + 2; i++) {
        if (cosa[i] != null || cosa[i] == "undefined") {
            agregar += cosa[i] + ",";
        }

    }
    localStorage.setItem("objetos", agregar);
}

function moverPersonaje(direccion, celdaObjetivo) {
    if (poderMoverse == true) {

        dir = direccion;
        if (celdaObjetivo != null) {
            esObstaculo = celdaObjetivo.className.search("obstaculo");
            if (celdaObjetivo != null && esObstaculo < 0) {
                jugador.className = "";
                if (pasos == 5) //cada 5 pasos se abre un combate 
                {
                    window.open("../pag/combate.html");
                    pasos = 0;
                    setTimeout(function () {
                        document.getElementById("nombre").innerHTML = localStorage.getItem("Jugador");
                        document.getElementById("nivel").innerHTML = "Nivel: " + nivelPersonaje;
                        document.getElementById("pv").innerHTML = "PV: " + localStorage.getItem("vidaPersonaje");
                        document.getElementById("exp").innerHTML = "Next lvl: " + localStorage.getItem("experienciaFaltante");
                    }, 3000);
                }
                pasos++;

                celdaObjetivo.className = "j " + generoJugador + "_" + direccion;

            } else {
                jugador.className = "j " + generoJugador + "_" + direccion;
            }
        }
    }
}
