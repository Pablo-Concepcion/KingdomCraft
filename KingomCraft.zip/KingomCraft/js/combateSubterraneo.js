function sub() {
    num = Math.abs(Math.floor(Math.random() * (2 - 0)) + 0);
    return num;
}
