objetos = localStorage.getItem("objetos");
cosa = objetos.split(",");
vidaPersonaje = localStorage.getItem("vidaPersonaje");
experienciaFaltante = localStorage.getItem("experienciaFaltante");
nivelPersonaje = localStorage.getItem("nivelPersonaje");
vida = localStorage.getItem("vida");
fin = localStorage.getItem("Fin");
sexo = localStorage.getItem("sexo");
poderMoverse = true;
if (sexo == "Mujer") {
    generoJugador = "jugadora";
} else {
    generoJugador = "jugador"; //segun el género escogido tendrá una apariencia de hombre o mujer
}
if(localStorage.getItem("Jugador") === null)//si no hay nombre de jugador redireccionamos al inicio
	{
		window.location.assign("../introduccion.html");
	}

function mover(e) {
    jugador = document.getElementsByClassName("j")[0];
    x = parseInt(jugador.getAttribute("id").split(",")[0]);
    y = parseInt(jugador.getAttribute("id").split(",")[1]);
    if (!e) {
        e = window.event;
    }
    switch (e.keyCode) {
        //--------------control de código de letras
        case 37: //izquierda
            nuevaPosicion = x + "," + (y - 1);
            celdaObjetivo = document.getElementById(nuevaPosicion);
            moverPersonaje("izquierda", celdaObjetivo);
            break;
            //----------------------------------------------
        case 38: //flecha "arriba"
            nuevaPosicion = (x - 1) + "," + y;
            celdaObjetivo = document.getElementById(nuevaPosicion);
            moverPersonaje("arriba", celdaObjetivo);
            break;
            //----------------------------------------------
        case 39: //derecha
            nuevaPosicion = x + "," + (y + 1);
            celdaObjetivo = document.getElementById(nuevaPosicion);
            moverPersonaje("derecha", celdaObjetivo);
            break;
            //----------------------------------------------		
        case 40: //abajo
            nuevaPosicion = (x + 1) + "," + y;
            celdaObjetivo = document.getElementById(nuevaPosicion);
            moverPersonaje("abajo", celdaObjetivo);
            break;
            //----------------------------------------------
        case 65: //letra a
            interaccionar(jugador.className);
            break;
    }
}

function interaccionar(direccionJugador) {
    switch (direccionJugador) {
        /*control de la letra "a"*/
        case "j " + generoJugador + "_" + "arriba":
            posicionDelObjeto = (x - 1) + "," + y;
            objeto = document.getElementById(posicionDelObjeto);
            comprobarPosicion(objeto, direccionJugador);
            //-------------------
            break;
        case "j " + generoJugador + "_" + "derecha":
            posicionDelObjeto = x + "," + (y + 1);
            objeto = document.getElementById(posicionDelObjeto);
            comprobarPosicion(objeto, direccionJugador);
            break;
            //-------------------
        case "j " + generoJugador + "_" + "abajo":
            posicionDelObjeto = (x + 1) + "," + y;
            objeto = document.getElementById(posicionDelObjeto);
            comprobarPosicion(objeto, direccionJugador);
            break;
            //-------------------
        case "j " + generoJugador + "_" + "izquierda":
            posicionDelObjeto = x + "," + (y - 1);
            objeto = document.getElementById(posicionDelObjeto);
            comprobarPosicion(objeto, direccionJugador);
            break;
    }
}

function agregarAlInventario(item) {//se agrega el elemento encontrado en los cofres al inventario
    if (item !== null) {
        if (item.substring(0, 6) == "Poción") {
            li = document.createElement("li");
            inventario = document.getElementById("itemsObjetos");
            li.setAttribute("class", "objetos");
            li.setAttribute("onclick", "usar(this)");
            cosa[cosa.length] = "Poción";
            texto = document.createTextNode(item);
            li.appendChild(texto);
            inventario.appendChild(li);
        } else if (item.substring(0, 9) == "MaxPoción") {
            li = document.createElement("li");
            inventario = document.getElementById("itemsObjetos");
            li.setAttribute("class", "objetosD");
            li.setAttribute("onclick", "usar(this)");
            cosa[cosa.length + 1] = "MaxPoción";
            texto = document.createTextNode(item);
            li.appendChild(texto);
            inventario.appendChild(li);
        }
        anadir();
    }
}

function agregarAlInventario2(item) {//agregamos al inventario los objetos del localStorage
    if (item !== null && item !== undefined) {
        if (item.substring(0, 6) == "Poción") {
            li = document.createElement("li");
            inventario = document.getElementById("itemsObjetos");
            li.setAttribute("class", "objetos");
            li.setAttribute("onclick", "usar(this)");
            cosa[cosa.length - 1] = "Poción";
            texto = document.createTextNode(item);
            li.appendChild(texto);
            inventario.appendChild(li);
        } else if (item.substring(0, 9) == "MaxPoción") {
            li = document.createElement("li");
            inventario = document.getElementById("itemsObjetos");
            li.setAttribute("class", "objetosD");
            li.setAttribute("onclick", "usar(this)");
            cosa[cosa.length - 1] = "MaxPoción";
            texto = document.createTextNode(item);
            li.appendChild(texto);
            inventario.appendChild(li);
        }

    }
}

function anadir() {//agregamos la lista de objetos al localStorage
    agregar = "";
    for (i = 0; i < cosa.length; i++) {
        agregar += cosa[i] + ",";
    }
    localStorage.setItem("objetos", agregar);
}

function usar(obj) {//se usa el objeto y se borra
    objetoUsar = obj.innerHTML;
    vidaPersonaje = parseInt(vidaPersonaje);
    switch (objetoUsar) {
        case "Poción":
            if (vidaPersonaje < vida && vidaPersonaje > 0) {
                vidaPersonaje += 50;
                if (vidaPersonaje > vida) {
                    vidaPersonaje = vida;
                    quitar(obj);
                    toastr.clear();
                    toastr.options.positionClass = "toast-top-center";
                    toastr.success('Has usado una Poción', '<i>Poción</i>');
                    localStorage.setItem("vidaPersonaje", vidaPersonaje);
                }
            } else {
                toastr.clear();
                toastr.options.positionClass = "toast-top-center";
                toastr.info('No te haría ningún efecto', '<i>Poción</i>');
            }
            break;
        case "MaxPoción":
            if (vidaPersonaje < vida && vidaPersonaje > 0) {

                vidaPersonaje = vida;

                quitar(obj);
                    toastr.clear();
                    toastr.options.positionClass = "toast-top-center";
                    toastr.success('Has usado una MaxPoción', '<i>MaxPoción</i>');

            } else {
                toastr.clear();
                toastr.options.positionClass = "toast-top-center";
                toastr.info('No te haría ningún efecto', '<i>MaxPoción</i>');
            }
            break;
    }

    document.getElementById("pv").innerHTML = "PV: " + vidaPersonaje;
}

function curar() {
    vidaPersonaje = vida;
    document.getElementById("pv").innerHTML = "PV: " + vidaPersonaje;
    localStorage.setItem("vidaPersonaje", vidaPersonaje);
}

function quitar(obj) {//removemos el objeto
    papaObj = obj.parentNode;
    papaObj.removeChild(obj);
}

function resetear() {//borramos partida y comenzamos otra desde cero
    $("#destruir").dialog({
        buttons: {
            Sí: function () {
                tamano = localStorage.length;
                for (i = tamano - 1; i >= 0; i--) {
                    localStorage.removeItem(localStorage.key(i));
                }
                window.open("../introduccion.html");
                window.close();
            },
            No: function () {
                $(this).dialog("close");
            }

        }
    });



}

function esconderCharlas() {//esconde todos los diálogos
    for (i = 1; i <= 3; i++) {
        for (j = 1; j <= 4; j++) {
            $("#dialogoAldeano" + i + "_" + j + "").hide();
        }

    }
    $("#puerta").hide();



    $("#dialogoAldeano1_1").hide();
    $("#mensajes").accordion({
        collapsible: true
    });
    $("#Objetos").accordion({
        collapsible: true,
        heightStyle: "content"
    });
}

function hablar(num1) { //hablan los personajes, esta función podría ser factorizada con un bucle, ¿podrás hacerlo?
    num = 1;
    poderMoverse = false;
    $("#dialogoAldeano" + num1 + "_" + num).dialog({
        buttons: {
            Vale: function () {
                num++;
                $(this).dialog("close");
                poderMoverse = false;
                $("#dialogoAldeano" + num1 + "_" + num).dialog({
                    buttons: {
                        Vale: function () {
                            num++;
                            $(this).dialog("close");
                            poderMoverse = false;
                            $("#dialogoAldeano" + num1 + "_" + num).dialog({
                                buttons: {
                                    Vale: function () {
                                        num++;
                                        $(this).dialog("close");
                                        $("#dialogoAldeano" + num1 + "_" + num).dialog({
                                            buttons: {
                                                Vale: function () {
                                                    num = 0;
                                                    $(this).dialog("close");
                                                    poderMoverse = true;
                                                },
                                            },
                                            close: function () {
                                                poderMoverse = true;
                                            },
                                            hide: {
                                    effect: "explode",
                                    duration: 1000
                                }
                                        });
                                    },
                                },
                                close: function () {
                                    poderMoverse = true;
                                },
                                hide: {
                                    effect: "explode",
                                    duration: 1000
                                }
                            });
                        },
                    },
                    close: function () {
                        poderMoverse = true;
                    },
                    hide: {
                        effect: "explode",
                        duration: 1000
                    }
                });
            },
        },
        close: function () {
            poderMoverse = true;
        },
        hide: {
            effect: "explode",
            duration: 1000
        }
    });


}

function toastear(tipo, texto, title) {//se crea el toastr según el tipo que sea
    toastr.clear();
    toastr.options.positionClass = "toast-top-center";
    switch (tipo) {
        case "exito":
            toastr.success(texto, '<i>' + title + '</i>');
            break;
        case "info":
            toastr.info(texto, '<i>' + title + '</i>');
            break;
        case "warning":
            toastr.warning(texto, '<i>' + title + '</i>');
            break;
        case "danger":
            toastr.error(texto, '<i>' + title + '</i>');
            break;
    }

}
function colocarEstado()
{
    document.getElementById("nombre").innerHTML = localStorage.getItem("Jugador");
    document.getElementById("nivel").innerHTML = "Nivel: " + nivelPersonaje;
    document.getElementById("pv").innerHTML = "PV: " + localStorage.getItem("vidaPersonaje");
    document.getElementById("exp").innerHTML = "Next lvl: " + localStorage.getItem("experienciaFaltante");
    inventario = document.getElementById("itemsObjetos");
    hijosInventario = inventario.childNodes;
    for (i=hijosInventario.length-1; i>= 0; i--)
    {
        inventario.removeChild(hijosInventario[i]);
    }
    
    objetos = localStorage.getItem("objetos");
    cosa = objetos.split(",");
    for (i = 0; i < cosa.length - 1; i++) {
        agregarAlInventario2(cosa[i]);
    }
}
