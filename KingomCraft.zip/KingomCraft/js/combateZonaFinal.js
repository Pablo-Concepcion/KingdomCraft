function sub() {
    num = Math.abs(Math.floor(Math.random() * (4 - 2)) + 2);
    return num;
}
