﻿pattlet = /^[ A-zá-ú]+$/; //patrón de validación
function jugar()
{
	nombre = document.getElementById("nombre").value;
	eleccionDeSexo = document.getElementsByName("sexo");
	for(i=0; i<eleccionDeSexo.length; i++)//recorro los radio button para ver si alguno está checkeado
	{
		if(eleccionDeSexo[i].checked== true)
		{
			sexo = eleccionDeSexo[i].value;//asigno el sexo checkeado
		}
	}
	if( nombre.match(pattlet)==null)
	{
		alert("Debe escribir el nombre sólo con letras.");
	}
	else if(confirm("Así que te llamas '"+nombre+ "' y eres " +sexo+ " ¿Verdad?"))
	{
		localStorage.setItem("Jugador", nombre);
		localStorage.setItem("sexo", sexo);
		alert("Se ha creado tu personaje");
		pestañear();//redirecciona la pestaña a la siguiente página
	}
	
}
function pestañear()
{
	window.location.assign("pag/inicio.html");
}