nivelPersonaje = 1;
porcentajeAtaque = 0.5;
porcentajeAtaqueOriginal = 0.5;
porcentajeDefensaOriginal = 0.5;
porcentajeDefensa = 0.5;
vida = vidaPersonaje = 50;
vidaPersonajeOriginal = 50;
enemigos = "slime.png,pragtok.png,stentun.png,stantos.png,boss.png";
ataqueBicho = 0.5;
experienciaPersonaje = 0;
experienciaFaltante = 60;
datosDelslime = "slime: 25,vida: 25,ataque: 0.1,defensa: 0.1";
datosDelpragtok = "pragtok: 45,vida: 50,ataque: 0.2,defensa: 0.3";
datosDelstentun = "stentun: 90,vida: 100,ataque: 0.4,defensa: 0.6";
datosDelstantos = "stantos: 180,vida: 150,ataque: 0.5,defensa: 0.6";
datosDelboss = "boss: 1800,vida: 200,ataque: 1,defensa: 2";
localStorage.setItem("datosDelboss", datosDelboss);
localStorage.setItem("experienciaPersonaje", experienciaPersonaje);
localStorage.setItem("experienciaFaltante", experienciaFaltante);
localStorage.setItem("datosDelslime", datosDelslime);
localStorage.setItem("datosDelpragtok", datosDelpragtok);
localStorage.setItem("datosDelstentun", datosDelstentun);
localStorage.setItem("datosDelstantos", datosDelstantos);
localStorage.setItem("enemigos", enemigos);
localStorage.setItem("nivelPersonaje", nivelPersonaje);
localStorage.setItem("porcentajeAtaque", porcentajeAtaque);
localStorage.setItem("porcentajeAtaqueOriginal", porcentajeAtaqueOriginal);
localStorage.setItem("porcentajeDefensa", porcentajeDefensa);
localStorage.setItem("porcentajeDefensaOriginal", porcentajeDefensaOriginal);
localStorage.setItem("vidaPersonaje", vidaPersonaje);
localStorage.setItem("vidaPersonajeOriginal", vidaPersonajeOriginal);
localStorage.setItem("vida", vidaPersonaje); //valor que se tomara de referencia para curacion
localStorage.setItem("objetos", "Poción,Poción,");
localStorage.setItem("Fin", "no");
localStorage.setItem("habilidades", "Espada fugaz,Espada lateral,Espada sabia,Espada mortal");
objetos = localStorage.getItem("objetos");
cosa = objetos.split(",");

//se definen todos los parámetros y datos de los enemigos 
dir = "";
poderMoverse = true;
sexo = localStorage.getItem("sexo");
if (sexo == "Mujer") {
    generoJugador = "jugadora";
} else {
    generoJugador = "jugador";
}

//se globalizan todas las variables para usarlas con mayor facilidad
celdaDondeEmpiezaElJugador = "";
celdaObjetivo = "";
nuevaPosicion = "";
jugador = "";
x = "";
y = "";

function crear() //se crea el tablero
{
    $("#pocion").hide();
    $("#noPocion").hide();
    $("#destruir").hide();

    esconderCharlas() //esconde las palabras de los aldeanos
    numeroFilas = 10;
    div = document.getElementsByClassName("tablero")[0];
    table = document.createElement("table");
    for (i = 0; i < numeroFilas - 1; i++) {
        tr = document.createElement("tr");
        for (j = 0; j < numeroFilas * 2; j++) {
            td = document.createElement("td");
            td.setAttribute("id", "" + i + "," + j + "");
            tr.appendChild(td);
        }
        table.appendChild(tr);
    }
    div.appendChild(table);
    crearObjetos();
    for (i = 0; i < cosa.length; i++) {
        agregarAlInventario2(cosa[i]);
    }
    document.getElementById("nombre").innerHTML = localStorage.getItem("Jugador");
    document.getElementById("nivel").innerHTML = "Nivel: " + nivelPersonaje;
    document.getElementById("pv").innerHTML = "PV: " + vidaPersonaje;
    document.getElementById("exp").innerHTML = "Next lvl: " + experienciaFaltante;
}

function crearObjetos() //crea los objetos y personajes del mapa
{
    document.getElementById("6,8").className = "obstaculo casa";
    document.getElementById("0,19").className = "obstaculo casaJefe";
    document.getElementById("3,10").className = "obstaculo casa";
    document.getElementById("6,15").className = "obstaculo casa";
    for (i = 1; i < 2; i++) {
        for (j = 0; j < 10; j++) {
            document.getElementById(i + "," + j).className = "obstaculo casa";
        }
    }
    document.getElementById("0,0").className = "obstaculo cofre pocion";
    document.getElementById("5,12").className = "obstaculo cofre pocion";
    document.getElementById("3,11").className = "obstaculo cofre pocion";
    document.getElementById("6,16").className = "obstaculo cofre pocion";
    document.getElementById("2,4").className = "obstaculo aldeano";
    document.getElementById("5,11").className = "obstaculo aldeana";
    document.getElementById("5,19").className = "obstaculo aldiano2";
    document.getElementById("0,19").className = "obstaculo casaJefe";

    celdaDondeEmpiezaElJugador = document.getElementById("8,0");
    celdaDondeEmpiezaElJugador.className = "j " + generoJugador + "_arriba";
}

function comprobarPosicion(objeto, direccionJugador) //comprueba la posición del objeto o personaje
{
    orientacionPresonaje = "_" + direccionJugador.split("_")[1];
    pocion = objeto.className.search("pocion");
    aldeano2 = objeto.className.search("aldiano2");
    aldeano = objeto.className.search("aldeano");
    aldeana = objeto.className.search("aldeana");
    casaJefe = objeto.className.search("casaJefe");
    if (pocion > 0) {
        toastr.clear();
        toastr.options.positionClass = "toast-top-center";
        toastr.info('Has encontrado una poción', '<i>Poción</i>');
        objeto.className = "obstaculo abierto";
        agregarAlInventario("Poción");
    }

    if (aldeano2 > 0) {
        var num1 = 2;
        hablar(num1);

    }
    if (aldeana > 0) {
        num1 = 3;
        hablar(num1);
        objeto.className = "obstaculo aldeana" + orientacionPresonaje;


    }
    if (aldeano > 0) {
        num1 = 1;
        hablar(num1);
        objeto.className = "obstaculo aldeano" + orientacionPresonaje;


    }
    if (casaJefe > -1) {
        poderMoverse = false;
        $("#puerta").dialog({
            buttons: {
                Entro: function () {
                    anadir(); //se anaden los objetos al localStorage cuando se pasa de mapa
                    window.location.assign("casaJefe.html");
                }
            },
            close: function () {
                poderMoverse = true;
            }
        });





    }
}

function moverPersonaje(direccion) {
    if (poderMoverse === true) {
        dir = direccion;
        if (celdaObjetivo !== null) {
            esObstaculo = celdaObjetivo.className.search("obstaculo");
            if (celdaObjetivo !== null && esObstaculo < 0) {
                jugador.className = "";
                celdaObjetivo.className = "j " + generoJugador + "_" + direccion;

            } else {
                jugador.className = "j " + generoJugador + "_" + direccion;
            }
        }
    }
}
